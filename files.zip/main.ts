/* =========================================================
   main.ts — الربط بين الوحدات (الإعداد + حلقة اللعبة)
   ========================================================= */
import * as THREE from "three";
import { World, chunkKey, parseChunkKey } from "./world";
import { WORLD_HEIGHT, CHUNK_SIZE, RENDER_DISTANCE, BLOCKS, HOTBAR } from "./core";
import { createRenderer, ChunkMesh } from "./render";
import { buildAtlas } from "./atlas";
import { Input } from "./input";
import { Player } from "./player";

/* ---------- الإعداد ---------- */
const app = document.getElementById("app")!;
const overlay = document.getElementById("overlay")!;
const hotbarEl = document.getElementById("hotbar")!;

const gr = createRenderer(app);
const chunkMaterial = new THREE.MeshBasicMaterial({ map: buildAtlas(), vertexColors: true });

const world = new World(12345);
const input = new Input(gr.renderer.domElement, overlay);
const player = new Player(world, input);

/* ---------- إدارة الـ chunk meshes ---------- */
const UNLOAD_DIST = RENDER_DISTANCE + 1;
const chunkMeshes = new Map<string, ChunkMesh>();

function ensureMesh(cx: number, cz: number): void {
  const k = chunkKey(cx, cz);
  if (chunkMeshes.has(k)) return;
  const cm = new ChunkMesh(world, world.ensureChunk(cx, cz), chunkMaterial);
  cm.update();
  gr.scene.add(cm.mesh);
  chunkMeshes.set(k, cm);
}

function loadAround(wx: number, wz: number): void {
  const ccx = Math.floor(wx / CHUNK_SIZE);
  const ccz = Math.floor(wz / CHUNK_SIZE);
  for (let dx = -RENDER_DISTANCE; dx <= RENDER_DISTANCE; dx++)
    for (let dz = -RENDER_DISTANCE; dz <= RENDER_DISTANCE; dz++)
      ensureMesh(ccx + dx, ccz + dz);
}

function unloadFar(wx: number, wz: number): void {
  const ccx = Math.floor(wx / CHUNK_SIZE);
  const ccz = Math.floor(wz / CHUNK_SIZE);
  for (const [k, cm] of chunkMeshes) {
    const [cx, cz] = parseChunkKey(k);
    if (Math.abs(cx - ccx) > UNLOAD_DIST || Math.abs(cz - ccz) > UNLOAD_DIST) {
      gr.scene.remove(cm.mesh);
      cm.dispose();
      chunkMeshes.delete(k);
    }
  }
  world.pruneDistant(wx, wz, UNLOAD_DIST); // التعديلات محفوظة داخل World
}

let lastCX = Number.NaN, lastCZ = Number.NaN;

/** لا تعمل إلا عند عبور حدود chunk */
function ensureAroundLoaded(wx: number, wz: number): void {
  const ccx = Math.floor(wx / CHUNK_SIZE);
  const ccz = Math.floor(wz / CHUNK_SIZE);
  if (ccx === lastCX && ccz === lastCZ) return;
  lastCX = ccx; lastCZ = ccz;
  loadAround(wx, wz);
  unloadFar(wx, wz);
}

/* ---------- نقطة الظهور ---------- */
world.ensureChunk(0, 0);
let spawnY = 20;
for (let y = WORLD_HEIGHT - 1; y >= 0; y--) {
  if (world.getBlock(0, y, 0) !== 0) { spawnY = y + 1; break; }
}
player.pos.set(0.5, spawnY + 0.1, 0.5);

loadAround(player.pos.x, player.pos.z);
lastCX = 0; lastCZ = 0;

/* ---------- شريط المكعبات ---------- */
let selected = 0;

function buildHotbarUI(): void {
  hotbarEl.innerHTML = "";
  HOTBAR.forEach((id, i) => {
    const slot = document.createElement("div");
    slot.className = "slot" + (i === selected ? " active" : "");
    slot.title = BLOCKS[id as keyof typeof BLOCKS].name;

    const sw = document.createElement("div");
    sw.className = "swatch";
    sw.style.backgroundColor = BLOCKS[id as keyof typeof BLOCKS].color;

    const num = document.createElement("span");
    num.className = "num";
    num.textContent = String(i + 1);

    slot.append(sw, num);
    hotbarEl.appendChild(slot);
  });
}
buildHotbarUI();

input.onBreak = () => player.breakBlock();
input.onPlace = () => player.placeBlock(HOTBAR[selected]);
input.onSelect = (i) => {
  if (i < 0 || i >= HOTBAR.length) return;
  selected = i;
  [...hotbarEl.children].forEach((el, j) => el.classList.toggle("active", j === selected));
};

/* ---------- حلقة اللعبة ---------- */
let lastTime = performance.now();

function animate(): void {
  requestAnimationFrame(animate);

  const now = performance.now();
  const dt = Math.min((now - lastTime) / 1000, 0.05);
  lastTime = now;

  if (input.locked) {
    player.update(dt);
    input.update(dt);
  }

  gr.camera.position.copy(player.eyePosition());
  gr.camera.rotation.y = input.yaw;
  gr.camera.rotation.x = input.pitch;

  for (const cm of chunkMeshes.values()) cm.update();
  ensureAroundLoaded(player.pos.x, player.pos.z);

  gr.renderer.render(gr.scene, gr.camera);
}

animate();
